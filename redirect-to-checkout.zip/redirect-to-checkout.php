<?php
/*
Plugin Name: Redirect to Checkout on Add to Cart
Description: Redirects to the WooCommerce checkout page immediately after a product is added to the cart.
Version: 1.0
Author: YourName
*/

add_filter('woocommerce_add_to_cart_redirect', 'custom_redirect_to_checkout');

function custom_redirect_to_checkout($url) {
    return wc_get_checkout_url();
}

// Optional: Disable cart fragments script (optional performance boost)
add_filter('woocommerce_cart_redirect_after_error', 'custom_redirect_to_checkout');
